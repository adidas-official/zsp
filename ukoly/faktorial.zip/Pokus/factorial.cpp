#include "factorial.hpp"

int factorial(int n) {
    // tady vytvo��te definici funkce factorial
    return -1;
}
